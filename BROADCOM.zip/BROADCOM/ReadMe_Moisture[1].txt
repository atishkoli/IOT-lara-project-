Control Stepper motor using Moisture sensor 



Library Used:

	


Thingspeak connection: 


import httplib
		
import urllib
		Establish the connection between Rasberry pi and Thingspeak
	

Functions:
			
params=urllib.urlencode({'field1': Moisture, 'key':key})# 'field2': flag, 'key':key})
        		
headers = {"Content-typZZe": "application/x-www-form-urlencoded","Accept": "text/plain"}
        		
conn = httplib.HTTPConnection("api.thingspeak.com:80")
		
     

stepper motor:
		
import RPi.GPIO as GPIO - for connecting the GPIO pins 
		
from time import sleep
		
import sys


    moisture sensor:
		
import spidev - To communicate with SPI devices
		
from numpy import interp  - To scale values
		
from time import sleep  - To add time delay




Components used:
	

1.Raspberry Pi 3b+
	
2.Moisture Sensor
	
3.MCP3008 Ic - Used to convert the analog output to the digital
	
4.Stepper Motor
	
5.Breadboard
	
6.Jumping Wires
	

Connections:

1.MC3008 IC:

IC pins	       	 

Raspberry pins

pin 16 (Vcc)  -   pin 1(3.3V)

pin 15 (Vdd)  -  pin 1(3.3V)

pin 14 (GND)  -  pin 6(GND)

pin 13 (CLK)  -  pin 23(SCLK)

pin 12 (MISO)  - pin 21

pin 11 (MOSI)  -  pin 19

pin 10 (CS)    -  pin 24

pin 9 (GND)    -  pin 6

2.

Moisture Sensor:
	
	

A0 -CH0 MCP3008
	
Vcc - 5v pin 2

GND - GND pin 6



3.


Stepper Motor with Raspberry Pi
	
	
IN1 - pin 29
	
IN2 - pin 31
	
In3 - pin 33
	
In4 - pin 35
 	
Vcc - pin 2(5V)
   	
GND - pin 6



Protocol Used: 

SPI (Serial Peripheral Interface) Protocol:
		

Key Pins of SPI Protocol:
		
1) MISO (Master In Slave Out)
		 
2) MOSI (Master Out Slave In)
		
3) SCLK (Serial Clock)
		
4) CS (Chip Select)


Working:
	 


Description:

This sensor can be used to test the moisture of soil, when the soil is having water shortage, the module output is at high level, else the output is
at low level. By using this sensor one can automatically water the flower plant, or any other plants requiring automatic watering
technique. Module triple output mode, digital output is simple, analog output more accurate, serial output with exact readings.


There are two probes in moisture sensor which are used to detect amount of moisture content in the soil. The sensor uses two probes to pass current 
through the soil and then it reads the resistance to get the moisture level. More water makes the soil conduct electricity more easily (less resistance),
while dry soil conducts electricity poorly (more resistance).It will be helpful to remind us to water your indoor plants or to monitor the soil moisture in your
garden.

   
	






